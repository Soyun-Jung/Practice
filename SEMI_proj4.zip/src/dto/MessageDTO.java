package dto;

public class MessageDTO {
	private String MS_RECID;
	private String MS_SENDID;
	private String MS_TEXT;
	private String MS_TITLE;
	private String MS_DATE;
	
	public String getMS_RECID() {
		return MS_RECID;
	}
	public void setMS_RECID(String mS_RECID) {
		MS_RECID = mS_RECID;
	}
	public String getMS_SENDID() {
		return MS_SENDID;
	}
	public void setMS_SENDID(String mS_SENDID) {
		MS_SENDID = mS_SENDID;
	}
	public String getMS_TEXT() {
		return MS_TEXT;
	}
	public void setMS_TEXT(String mS_TEXT) {
		MS_TEXT = mS_TEXT;
	}
	public String getMS_TITLE() {
		return MS_TITLE;
	}
	public void setMS_TITLE(String mS_TITLE) {
		MS_TITLE = mS_TITLE;
	}
	public String getMS_DATE() {
		return MS_DATE;
	}
	public void setMS_DATE(String mS_DATE) {
		MS_DATE = mS_DATE;
	}
	
}
