package dto;

public class MemberDTO {

		private String mb_id;
		private String mb_pw;
		private String mb_name;
		private String mb_loc;
		private String mb_phone;
		private String mb_level;
		private String mb_state;
		private int mb_postCode;
		private String mb_roadAddr;
		private String mb_jibunAddr;
		private String mb_detailAddr;
		private String mb_exAddr;
		
		public String getMb_id() {
			return mb_id;
		}
		public void setMb_id(String mb_id) {
			this.mb_id = mb_id;
		}
		public String getMb_pw() {
			return mb_pw;
		}
		public void setMb_pw(String mb_pw) {
			this.mb_pw = mb_pw;
		}
		public String getMb_name() {
			return mb_name;
		}
		public void setMb_name(String mb_name) {
			this.mb_name = mb_name;
		}
		public String getMb_loc() {
			return mb_loc;
		}
		public void setMb_loc(String mb_loc) {
			this.mb_loc = mb_loc;
		}
		public String getMb_phone() {
			return mb_phone;
		}
		public void setMb_phone(String mb_phone) {
			this.mb_phone = mb_phone;
		}
		public String getMb_level() {
			return mb_level;
		}
		public void setMb_level(String mb_level) {
			this.mb_level = mb_level;
		}
		public String getMb_state() {
			return mb_state;
		}
		public void setMb_state(String mb_state) {
			this.mb_state = mb_state;
		}
		public int getMb_postCode() {
			return mb_postCode;
		}
		public void setMb_postCode(int mb_postCode) {
			this.mb_postCode = mb_postCode;
		}
		public String getMb_roadAddr() {
			return mb_roadAddr;
		}
		public void setMb_roadAddr(String mb_roadAddr) {
			this.mb_roadAddr = mb_roadAddr;
		}
		public String getMb_jibunAddr() {
			return mb_jibunAddr;
		}
		public void setMb_jibunAddr(String mb_jibunAddr) {
			this.mb_jibunAddr = mb_jibunAddr;
		}
		public String getMb_detailAddr() {
			return mb_detailAddr;
		}
		public void setMb_detailAddr(String mb_detailAddr) {
			this.mb_detailAddr = mb_detailAddr;
		}
		public String getMb_exAddr() {
			return mb_exAddr;
		}
		public void setMb_exAddr(String mb_exAddr) {
			this.mb_exAddr = mb_exAddr;
		}
}
