package service;

import static dao.MessageDAO.getInstance;
import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import dao.MessageDAO;
import dto.MessageDTO;

public class MsgListService {



	public ArrayList<MessageDTO> getMessageList(String ID) {
		// 공통부분
		MessageDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		ArrayList<MessageDTO> msglist = dao.getMsgList(ID);
		close(con);
		
		return msglist;
		
	}

	
}
