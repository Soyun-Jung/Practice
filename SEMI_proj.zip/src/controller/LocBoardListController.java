package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.MemberDTO;
import dto.PageDTO;
import service.BoardListService;


@WebServlet("/getList")
public class LocBoardListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LocBoardListController() {
		super();
		// TODO Auto-generated constructor stub
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		BoardListService lsv = new BoardListService();
		PageDTO pdto = new PageDTO();
		MemberDTO mdto = new MemberDTO();

		if(request.getParameter("page")!=null) {
			pdto.setNowPage(Integer.parseInt(request.getParameter("page")));
		}else {
			pdto.setNowPage(1);
		}
		mdto.setMb_loc(request.getParameter("Loc"));
		
		request.setAttribute("page", pdto);
		request.setAttribute("Loc", mdto.getMb_loc());
		request.setAttribute("board", lsv.BoardList(mdto, pdto));
		RequestDispatcher dispatcher = request.getRequestDispatcher("BoardList.jsp");
		dispatcher.forward(request, response);
	}

}
