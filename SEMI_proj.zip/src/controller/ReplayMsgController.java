package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.BoardListDTO;
import dto.MessageDTO;
import service.CommentListService;
import service.MsgWriteService;
import service.ViewService;

/**
 * Servlet implementation class ReplayMsgController
 */
@WebServlet("/ReplayMsg")
public class ReplayMsgController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReplayMsgController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		MessageDTO ms = new MessageDTO();
		MsgWriteService mws = new MsgWriteService();
		
		ms.setMs_bdmbid(request.getParameter("Reciever"));
		ms.setMs_mbid(request.getParameter("Sender"));
		ms.setMs_text(request.getParameter("message"));
		ms.setMs_bdnum(Integer.parseInt(request.getParameter("Bdnum")));
		
		if(mws.MsgWrite(ms)) { // BoardWrite.1
			ViewService viewsvc = new ViewService();
			BoardListDTO board = new BoardListDTO();
			board.setBD_NUM(Integer.parseInt(request.getParameter("BdNum")));
			
			if(viewsvc.BoardView(board)) {
				CommentListService cls = new CommentListService();
				RequestDispatcher dispatcher = request.getRequestDispatcher("BoardDetail.jsp");
				
				request.setAttribute("view", board);
				request.setAttribute("comment", cls.getCommentList(board));
				request.setAttribute("page", request.getParameter("page"));
				dispatcher.forward(request, response);
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("MessageList.jsp");
				dispatcher.forward(request, response);
			}
			
		}
	}

}
