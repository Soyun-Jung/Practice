package service;

import static dao.BoardDAO.*;
import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.BoardDAO;
import dto.BoardDTO;
import dto.MemberDTO;

public class BoardListService {
	//전체 리스트 불러오기
	public ArrayList<BoardDTO> BoardList() {
		// 공통부분
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardDTO> boardlist = dao.BoardList();
		close(con);
		
		return boardlist;
	}
	
	//loc설정된 리스트 불러오기
	public ArrayList<BoardDTO> BoardList(String loc) {
		// 공통부분
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardDTO> boardlist = dao.BoardList(loc);
		close(con);
		
		return boardlist;
	}

	public ArrayList<BoardDTO> BoardSearchList(String search) {
		// TODO Auto-generated method stub
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardDTO> boardlist = dao.BoardList2(search);
		close(con);
		
		return boardlist;
	}

	public ArrayList<BoardDTO> BoardLocSearchList(String search, String loc) {
		// TODO Auto-generated method stub
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardDTO> boardlist = dao.BoardList3(search, loc);
		close(con);
		
		return boardlist;
	}
	
	public ArrayList<BoardDTO> myBoardList(MemberDTO mdto){
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		ArrayList<BoardDTO> boardlist = dao.myBoardList(mdto);
		close(con);
		return boardlist;
	}
}







