package service;

import java.sql.Connection;
import java.util.ArrayList;

import static dao.MemberDAO.*;
import dao.MemberDAO;
import static db.JdbcUtil.*;
import dto.MemberDTO;
import dto.PageDTO;

public class UserListService {

	public UserListService() {
		
	}
	
	public ArrayList<MemberDTO> getUserList(MemberDTO mdto, PageDTO pdto){
		ArrayList<MemberDTO> userList = null;
		MemberDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		int limit = 5;
		pdto.setListCount(dao.getUserCount());
		pdto.setMaxPage((int)((double)pdto.getListCount()/limit + 0.9));
		pdto.setStartPage(((int)((double)pdto.getPage()/10 + 0.9) - 1) * 10 + 1);
		pdto.setEndPage(((pdto.getStartPage() + 10 -1)<pdto.getMaxPage())?(pdto.getStartPage() + 10 -1):pdto.getMaxPage());
		
		int start = pdto.getListCount() - ((pdto.getPage() - 1) * limit);
		int end = ((pdto.getListCount() - (pdto.getPage() * limit -1))>=0)?(pdto.getListCount() - (pdto.getPage() * limit -1)):0;
		
		userList = dao.getUserList(start, end);
		
		close(con);
		return userList;
	}
}
