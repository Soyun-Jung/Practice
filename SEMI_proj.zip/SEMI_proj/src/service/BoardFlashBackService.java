package service;

import java.sql.Connection;

import static dao.BoardDAO.*;
import dao.BoardDAO;
import static db.JdbcUtil.*;
import dto.BoardDTO;

public class BoardFlashBackService {

	public BoardFlashBackService() {
		
	}
	
	public boolean setBoardFlashBack(BoardDTO bdto) {
		boolean tran = false;
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		tran = dao.setBoardContent(bdto);
		if(tran) {
			commit(con);
		}else {
			rollback(con);
		}
		close(con);
		return tran;
	}
}
