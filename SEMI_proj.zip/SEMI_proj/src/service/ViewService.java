package service;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.BoardDAO;
import static dao.BoardDAO.*;
import dto.BoardDTO;

public class ViewService {

	public BoardDTO BoardView(int bNum) {
		// 공통부분
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		BoardDTO board = null;
		// (1)조회수 증가
		if(dao.BoardBhit(bNum)) {
			board = dao.BoardView(bNum);
			commit(con);
		} else {
			rollback(con);
		}
		
		// (2)상세보기
		
		close(con);
		return board;
	}

}