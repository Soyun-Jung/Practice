package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.BoardDTO;
import dto.MemberDTO;

import static db.JdbcUtil.*;

public class BoardDAO {
	private static BoardDAO dao;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public BoardDAO() {
		
	}
	
	// getInstance메소드
	public static BoardDAO getInstance() {
		if (dao == null) {
			dao = new BoardDAO();
		}
		return dao;
	}

	// setConnection 메소드
	public void setConnection(Connection con) {
		this.con = con;
	}
	
	public boolean setBoardWrite(BoardDTO bdto) {
		boolean result = false;
		String sql = "INSERT INTO BOARD(BD_NUM, BD_TITLE, BD_MBID, BD_CONTENT, BD_FILE, BD_HIT, BD_DATE, BD_STATE, BD_DEL)\r\n" + 
				"VALUES(BD_NUM_SEQ.NEXTVAL, ?, ?, ?, ?, DEFAULT, DEFAULT, ?, DEFAULT)";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setNString(1, bdto.getBd_title());
			pstmt.setNString(2, bdto.getBd_mbid());
			pstmt.setNString(3, bdto.getBd_content());
			pstmt.setNString(4, bdto.getBd_file());
			pstmt.setNString(5, bdto.getBd_state());
			result = (pstmt.executeUpdate()==1)?true:false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result;
	}
	
	public int getBoardCount() {
		int result = 0;
		String sql = "SELECT MAX(BD_NUM)\r\n" + 
				"FROM BOARD";
		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				result = rs.getInt(1); // BoardList.4
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}
		return result; // BoardList.5
	}

	public ArrayList<BoardDTO> getBoardList(int start, int end) {
		ArrayList<BoardDTO> result = null;
		String sql = "SELECT * FROM BOARD WHERE BD_NUM BETWEEN ? AND ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, end);
			pstmt.setInt(2, start);
			rs = pstmt.executeQuery();
			result = new ArrayList<BoardDTO>();
			BoardDTO bdto;
			while(rs.next()) { // BoardList.7
				bdto = new BoardDTO();
				bdto.setBd_num(rs.getInt("BD_NUM"));
				bdto.setBd_title(rs.getNString("BD_TITLE"));
				bdto.setBd_mbid(rs.getNString("BD_MBID"));
				bdto.setBd_del(rs.getInt("BD_DEL"));
				bdto.setBd_date(rs.getNString("BD_DATE"));
				bdto.setBd_hit(rs.getInt("BD_HIT"));
				bdto.setBd_state(rs.getNString("BD_STATE"));
				result.add(bdto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
			close(rs);
		}
		return result; // BoardList.8
	}
	
	public boolean BoardBhit(int bNum) {
		// TODO Auto-generated method stub
		String sql = "UPDATE BOARD SET BD_HIT = BD_HIT+1 WHERE BD_NUM=?";
		boolean hitResult = false;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bNum);
			hitResult = (pstmt.executeUpdate()==1)?true:false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			close(pstmt);
		}

		return hitResult;
	}

	public BoardDTO BoardView(int bNum) {
		BoardDTO board = new BoardDTO();
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_CONTENT AS CONTENT,"
				+ " BD_FILE AS FILENAME,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid"
				+ " WHERE BD_NUM = ?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bNum);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				board.setBd_num(rs.getInt("NUM"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_content(rs.getNString("CONTENT"));
				board.setBd_file(rs.getNString("FILENAME"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_state(rs.getNString("STATE"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}
		System.out.println("dao :: " + board.toString());
		return board;
	}

	public int BoardDel(int bNum) {
		int delResult = 0;
		String sql = "DELETE BOARDT WHERE BNUM=?";

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bNum);
			delResult = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return delResult;
	}

	public int ListCount() {
		String sql = "SELECT COUNT(*) FROM BOARD";
		int listCount = 0;

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				listCount = rs.getInt(1);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return listCount;
	}

	public ArrayList<BoardDTO> BoardList1(int startRow, int endRow, String loc) {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " MB_LOC AS LOC,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES"
				+ " FROM BOARDLIST"
				+ " WHERE RN BETWEEN ? AND ? AND MB_LOC =?";
		ArrayList<BoardDTO> boardList = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			pstmt.setNString(3, loc);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));

				boardList.add(board);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
			close(rs);
		}

		return boardList;
	}
	
	public ArrayList<BoardDTO> BoardList() {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE,"
				+ " BD_DEL AS DEL"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid";

		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_state(rs.getNString("STATE"));
				board.setBd_del(rs.getInt("DEL"));
				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}

	public ArrayList<BoardDTO> BoardList(String loc) {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE,"
				+ " BD_DEL AS DEL"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid"
				+ " WHERE MB_LOC=?";

		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setNString(1, loc);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_state(rs.getNString("STATE"));
				board.setBd_del(rs.getInt("DEL"));

				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}

	//검색 아이템
	public ArrayList<BoardDTO> BoardList2(String search) {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE,"
				+ " BD_DEL AS DEL"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid"
				+ " WHERE BD_TITLE LIKE '%'||?||'%'";

		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setNString(1, search);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_state(rs.getNString("STATE"));
				board.setBd_del(rs.getInt("DEL"));

				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}

	public ArrayList<BoardDTO> BoardList3(String search, String loc) {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE,"
				+ " BD_DEL AS DEL"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid"
				+ " WHERE MB_LOC=? AND BD_TITLE LIKE '%'||?||'%'";

		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			
			pstmt.setNString(1, loc);
			pstmt.setNString(2, search);
			
			System.out.println(search);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_state(rs.getNString("STATE"));
				board.setBd_del(rs.getInt("DEL"));

				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}
	
	public ArrayList<BoardDTO> myBoardList(MemberDTO mdto) {
		String sql = "SELECT BD_NUM AS NUM,"
				+ " MB_LOC AS LOC,"
				+ " BD_TITLE AS TITLE,"
				+ " BD_MBID AS ID,"
				+ " BD_HIT AS HITS,"
				+ " BD_DATE AS DATES,"
				+ " BD_STATE AS STATE,"
				+ " BD_DEL AS DEL"
				+ " FROM BOARD INNER JOIN MEMBERS ON members.mb_id=board.bd_mbid"
				+ " WHERE BD_MBID = ?";

		ArrayList<BoardDTO> boardlist = new ArrayList<BoardDTO>();
		BoardDTO board = null;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setNString(1, mdto.getMb_id());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				board = new BoardDTO();

				board.setBd_num(rs.getInt("NUM"));
				board.setBd_loc(rs.getNString("LOC"));
				board.setBd_title(rs.getString("TITLE"));
				board.setBd_mbid(rs.getNString("ID"));
				board.setBd_hit(rs.getInt("HITS"));
				board.setBd_date(rs.getNString("DATES"));
				board.setBd_state(rs.getNString("STATE"));
				board.setBd_del(rs.getInt("DEL"));
				boardlist.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
		}
		return boardlist;
	}
	
	public boolean BD_Modify(BoardDTO board) {
		String sql = "UPDATE BOARD SET BD_TITLE=?, BD_CONTENT=?, BD_FILE=?, BD_STATE=? WHERE BD_NUM=?";
		boolean result = false;
		
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, board.getBd_title());
			pstmt.setString(2, board.getBd_content());
			pstmt.setString(3, board.getBd_file());
			pstmt.setString(4, board.getBd_state());
			pstmt.setInt(5, board.getBd_num());			
			result = (pstmt.executeUpdate()==1)?true:false;
		} catch (SQLException e) {			
			e.printStackTrace();
		} finally {
			close(pstmt);
		}		
		
		return result;
	}

	public boolean BD_Delete(BoardDTO bdto) {		
		String sql = "UPDATE BOARD SET BD_DEL = -1 WHERE BD_NUM=?";
		boolean Del_result = false;

		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bdto.getBd_num());
			Del_result = (pstmt.executeUpdate()==1)?true:false;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(pstmt);
		}
		return Del_result;
	}

	public boolean setBoardContent(BoardDTO bdto) {
		boolean result = false;
		String sql = "UPDATE BOARD SET BD_DEL = 1 WHERE BD_NUM = ? AND BD_DEL = -1";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bdto.getBd_num());
			result = (pstmt.executeUpdate()==1)?true:false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(pstmt);
		}
		return result; // BoardContentFlashBack.5
	}
}
