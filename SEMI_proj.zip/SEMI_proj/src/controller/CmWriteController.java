package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dto.CommentDTO;
import service.CommentWriteService;

/**
 * Servlet implementation class CommentController
 */
@WebServlet("/CommentWrite")
public class CmWriteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CmWriteController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		CommentDTO comments = new CommentDTO();
		CommentWriteService cws = new CommentWriteService();
		
		comments.setCm_content(request.getParameter("cmtext"));
		comments.setCm_bdnum(Integer.parseInt(request.getParameter("bNum")));
		comments.setCm_mbid(request.getParameter("mbid"));
		
		if(cws.writeComments(comments)) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("boardView");
			request.setAttribute("bNum", request.getParameter("bNum"));
			request.setAttribute("page", request.getParameter("page"));
			dispatcher.forward(request, response);
		}

	}

}
