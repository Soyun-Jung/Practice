package dto;

public class UserListDTO {

	private String MB_ID;
	private String MB_PW;
	private String MB_NAME;
	private int MB_POSTCODE;
	private String MB_ROADADDR;
	private String MB_JIBUNADDR;
	private String MB_DETAILADDR;
	private String MB_EXADDR;
	private String MB_LOC;
	private String MB_PHONE;
	private String MB_LEVEL;
	private String MB_STATE;
	private int BR_REPORT;
	
	public String getMB_ID() {
		return MB_ID;
	}
	public void setMB_ID(String mB_ID) {
		MB_ID = mB_ID;
	}
	public String getMB_PW() {
		return MB_PW;
	}
	public void setMB_PW(String mB_PW) {
		MB_PW = mB_PW;
	}
	public String getMB_NAME() {
		return MB_NAME;
	}
	public void setMB_NAME(String mB_NAME) {
		MB_NAME = mB_NAME;
	}
	public String getMB_LOC() {
		return MB_LOC;
	}
	public void setMB_LOC(String mB_LOC) {
		MB_LOC = mB_LOC;
	}
	public String getMB_PHONE() {
		return MB_PHONE;
	}
	public void setMB_PHONE(String mB_PHONE) {
		MB_PHONE = mB_PHONE;
	}
	public String getMB_LEVEL() {
		return MB_LEVEL;
	}
	public void setMB_LEVEL(String mB_LEVEL) {
		MB_LEVEL = mB_LEVEL;
	}
	public String getMB_STATE() {
		return MB_STATE;
	}
	public void setMB_STATE(String mB_STATE) {
		MB_STATE = mB_STATE;
	}
	public int getBR_REPORT() {
		return BR_REPORT;
	}
	public void setBR_REPORT(int bR_REPORT) {
		BR_REPORT = bR_REPORT;
	}
	public int getMB_POSTCODE() {
		return MB_POSTCODE;
	}
	public void setMB_POSTCODE(int mB_POSTCODE) {
		MB_POSTCODE = mB_POSTCODE;
	}
	public String getMB_ROADADDR() {
		return MB_ROADADDR;
	}
	public void setMB_ROADADDR(String mB_ROADADDR) {
		MB_ROADADDR = mB_ROADADDR;
	}
	public String getMB_JIBUNADDR() {
		return MB_JIBUNADDR;
	}
	public void setMB_JIBUNADDR(String mB_JIBUNADDR) {
		MB_JIBUNADDR = mB_JIBUNADDR;
	}
	public String getMB_DETAILADDR() {
		return MB_DETAILADDR;
	}
	public void setMB_DETAILADDR(String mB_DETAILADDR) {
		MB_DETAILADDR = mB_DETAILADDR;
	}
	public String getMB_EXADDR() {
		return MB_EXADDR;
	}
	public void setMB_EXADDR(String mB_EXADDR) {
		MB_EXADDR = mB_EXADDR;
	}
}
