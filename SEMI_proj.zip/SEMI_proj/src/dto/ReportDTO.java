package dto;

public class ReportDTO {

	private int BR_BDNUM;
	private String BR_BDMBID;
	private String BR_MBID;
	
	public int getBR_BDNUM() {
		return BR_BDNUM;
	}
	public void setBR_BDNUM(int bR_BDNUM) {
		BR_BDNUM = bR_BDNUM;
	}
	public String getBR_BDMBID() {
		return BR_BDMBID;
	}
	public void setBR_BDMBID(String bR_BDMBID) {
		BR_BDMBID = bR_BDMBID;
	}
	public String getBR_MBID() {
		return BR_MBID;
	}
	public void setBR_MBID(String bR_MBID) {
		BR_MBID = bR_MBID;
	}
}
