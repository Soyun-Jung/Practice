package dto;

public class BoardDTO {
	private int bd_num;
	private String bd_title;
	private String bd_mbid;
	private String bd_content;
	private String bd_file;
	private int bd_hit;
	private String bd_date;
	private String bd_state;
	private int bd_del;
	private String bd_loc;
	
	public int getBd_num() {
		return bd_num;
	}
	public void setBd_num(int bd_num) {
		this.bd_num = bd_num;
	}
	public String getBd_title() {
		return bd_title;
	}
	public void setBd_title(String bd_title) {
		this.bd_title = bd_title;
	}
	public String getBd_mbid() {
		return bd_mbid;
	}
	public void setBd_mbid(String bd_mbid) {
		this.bd_mbid = bd_mbid;
	}
	public String getBd_content() {
		return bd_content;
	}
	public void setBd_content(String bd_content) {
		this.bd_content = bd_content;
	}
	public String getBd_file() {
		return bd_file;
	}
	public void setBd_file(String bd_file) {
		this.bd_file = bd_file;
	}
	public int getBd_hit() {
		return bd_hit;
	}
	public void setBd_hit(int bd_hit) {
		this.bd_hit = bd_hit;
	}
	public String getBd_date() {
		return bd_date;
	}
	public void setBd_date(String bd_date) {
		this.bd_date = bd_date;
	}
	public String getBd_state() {
		return bd_state;
	}
	public void setBd_state(String bd_state) {
		this.bd_state = bd_state;
	}
	public int getBd_del() {
		return bd_del;
	}
	public void setBd_del(int bd_del) {
		this.bd_del = bd_del;
	}
	public String getBd_loc() {
		return bd_loc;
	}
	public void setBd_loc(String bd_loc) {
		this.bd_loc = bd_loc;
	}
	
}
