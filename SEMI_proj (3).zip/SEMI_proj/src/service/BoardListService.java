package service;

import static dao.BoardDAO.*;
import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.BoardDAO;
import dto.BoardDTO;
import dto.BoardListDTO;
import dto.MemberDTO;

public class BoardListService {
	//전체 리스트 불러오기
	public ArrayList<BoardListDTO> BoardList() {
		// 공통부분
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardListDTO> boardlist = dao.BoardList();
		close(con);
		
		return boardlist;
	}
	
	//loc설정된 리스트 불러오기
	public ArrayList<BoardListDTO> BoardList(MemberDTO mdto) {
		// 공통부분
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardListDTO> boardlist = dao.BoardList(mdto);
		close(con);
		
		return boardlist;
	}

	public ArrayList<BoardListDTO> BoardList(BoardDTO bdto) {
		// TODO Auto-generated method stub
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardListDTO> boardlist = dao.BoardList(bdto);
		close(con);
		
		return boardlist;
	}

	public ArrayList<BoardListDTO> BoardList(BoardDTO bdto, MemberDTO mdto) {
		// TODO Auto-generated method stub
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		// 여기까지
		
		ArrayList<BoardListDTO> boardlist = dao.BoardList(bdto, mdto);
		close(con);
		
		return boardlist;
	}
	
	public ArrayList<BoardListDTO> myBoardList(MemberDTO mdto){
		BoardDAO dao = getInstance();
		Connection con = getConnection();
		dao.setConnection(con);
		ArrayList<BoardListDTO> boardlist = dao.myBoardList(mdto);
		close(con);
		return boardlist;
	}
}







