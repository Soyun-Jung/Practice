package dto;

public class MemberDTO {

		private String mb_id;
		private String mb_pw;
		private String mb_name;
		private String mb_loc;
		private String mb_phone;
		private String mb_level;
		private String mb_state;
		private String mb_add;
		
		public String getMb_id() {
			return mb_id;
		}
		public void setMb_id(String mb_id) {
			this.mb_id = mb_id;
		}
		public String getMb_pw() {
			return mb_pw;
		}
		public void setMb_pw(String mb_pw) {
			this.mb_pw = mb_pw;
		}
		public String getMb_name() {
			return mb_name;
		}
		public void setMb_name(String mb_name) {
			this.mb_name = mb_name;
		}
		public String getMb_loc() {
			return mb_loc;
		}
		public void setMb_loc(String mb_loc) {
			this.mb_loc = mb_loc;
		}
		public String getMb_phone() {
			return mb_phone;
		}
		public void setMb_phone(String mb_phone) {
			this.mb_phone = mb_phone;
		}
		public String getMb_level() {
			return mb_level;
		}
		public void setMb_level(String mb_level) {
			this.mb_level = mb_level;
		}
		public String getMb_state() {
			return mb_state;
		}
		public void setMb_state(String mb_state) {
			this.mb_state = mb_state;
		}
		public String getMb_add() {
			return mb_add;
		}
		public void setMb_add(String mb_add) {
			this.mb_add = mb_add;
		}
}
